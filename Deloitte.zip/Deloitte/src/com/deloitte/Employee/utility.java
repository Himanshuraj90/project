package com.deloitte.Employee;

public class utility {
	
	 public static boolean validateName(String empName)
	   {
		   String pattern="[A-Za-z]+$";
			if (empName.matches(pattern))
			{	return true;}
			else
			{ return false;}
	   }

	 public static boolean validateSalary(String salary)
	   {
		   String pattern="^[0-9]+[.]{1}[0-9]+$";
			if (salary.matches(pattern))
			{	return true;}
			else
			{ return false;}
	   }

}
