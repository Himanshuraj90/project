package com.deloitte.Employee;
import java.util.*;
public class Employee {
	private int empId;
	private String empName;
	private double salary;
	private String deptId;

	Employee() {

	}

	
	
	

	public int getEmpId() {
		return empId;
	}





	public void setEmpId(int empId) {
		this.empId = empId;
	}





	public String getEmpName() {
		return empName;
	}



  

	public void setEmpName(String empName) {
		if ((utility.validateName(empName))==true)
			this.empName = empName;
		
		else
			System.out.println("Please enter Alphabets only");
		
		
	}





	public double getSalary() {
		return salary;
	}





	public void setSalary(String salary) {
		if (utility.validateSalary(salary))
				this.salary = Double.parseDouble(salary);
			else
			     System.out.println("Please enter numbers only");
	}





	public String getDeptId() {
		return deptId;
	}





	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}





	public void deptChange(String deptname) {
		System.out.println("inside dept change method ");
	}
}
