package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.UserDetails;
import com.example.demo.services.UserService;

@Controller("ManageUserRoles")
@ResponseBody
public class UserController {
	@Autowired
	UserService uservice;

	@PostMapping("/addUser")
	public String addUser(@RequestBody UserDetails user) {
		System.out.println("controller");
		int affectedRows = uservice.addUser(user);
		if (affectedRows == 1)
			return "1 User added";
		else
			return "No User added";
	}

	@GetMapping("/getUser")
	public ArrayList<UserDetails> getMessage(@RequestParam("userId") int userId) {
		return uservice.display(userId);
	}

	@GetMapping("/form")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}

	@GetMapping("/login")
	public ModelAndView hello(@RequestParam("userName") String name, @RequestParam("Password") String pass) {
		ModelAndView modelAndView = new ModelAndView();

		System.out.println(name + pass);
		// modelAndView.setViewName("login");
		boolean b = uservice.validate(name, pass);
		if (b) {
			modelAndView.setViewName("login");
			modelAndView.addObject("result", "USER VERIFIED SUCCESSFULLY");
		} else {
			modelAndView.setViewName("login");
			modelAndView.addObject("result", "USER dont exist");
		}
		return modelAndView;
	}

}
