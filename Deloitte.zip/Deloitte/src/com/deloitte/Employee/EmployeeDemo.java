package com.deloitte.Employee;
import java.util.*;
public class EmployeeDemo {

	public static void main(String args[]) {
		
		Scanner sc=new Scanner(System.in);
		String name= sc.next();
		Employee emp1 = new Employee();
		emp1.setEmpId(12);
		emp1.setEmpName(name);
		System.out.println(emp1.getEmpName());
		emp1.setDeptId("SE");
		System.out.println(emp1.getEmpId());
		Scanner sc1=new Scanner(System.in);
		String sal=sc1.next();
		emp1.setSalary(sal);
		System.out.println(emp1.getSalary());
	}
}
