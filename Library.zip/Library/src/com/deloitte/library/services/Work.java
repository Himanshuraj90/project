package com.deloitte.library.services;
import java.util.*;

import com.deloitte.library.dao.BookDAO;
import com.deloitte.library.model.Book;



public class Work implements  bookInterface {


	public void addBook(String bookName, String author, int price) {
	
		Book c2=new Book();
		c2.setBookId(Book.getCount());
		c2.setBookName(bookName);
		c2.setAuthor(author);
		c2.setPrice(price);
		BookDAO.addBook(c2);
	}


	public boolean searchBook(int bookId,ArrayList<Book> c2 ){
			boolean flag = false;
			int flag1 = 0;
			for (Book p: c2) {
				if(bookId==p.getBookId())
					flag1 = 1;
				else
					flag1 = 0;
			}
			if (flag1 == 1)
				flag = true;
			else
				flag = false;

			return flag;
	}




	@Override
	public void displayBook() {
		// TODO Auto-generated method stub
		
	}

	
}
