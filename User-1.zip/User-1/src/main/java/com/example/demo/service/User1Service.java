package com.example.demo.service;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.User1DAO;
import com.example.demo.modal.User1Details;


@Service
public class User1Service {
	@Autowired
	User1DAO dao1;
	
	public ArrayList<User1Details> display() {
			return dao1.displayuser();
			
				}

	public void adddata(User1Details user1) {
		// TODO Auto-generated method stub
		
	}
	
	

}
