package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.UserDetails;
import com.example.demo.services.UserService;

@Controller
@ResponseBody
public class UserController {
	@Autowired
	UserService uservice;



	@GetMapping("/getUser")
	public ArrayList<UserDetails> getMessage(@RequestParam("userId") int userId) {
		return uservice.display(userId);
	}

	@GetMapping("/login")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}

	@GetMapping("/loginform")
	public ModelAndView hello(@RequestParam("userName") String userName, @RequestParam("password") String password) {
		ModelAndView modelAndView = new ModelAndView();

		System.out.println(userName + password);
	
		boolean b = uservice.validate(userName, password);
		if (b) {
			modelAndView.setViewName("/login");
			modelAndView.addObject("result", "USER VERIFIED SUCCESSFULLY");
		} else {
			modelAndView.setViewName("login");
			modelAndView.addObject("result", "No user Found");
		}
		return modelAndView;
	}
	
	@GetMapping("/registration")
	public ModelAndView register() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("Registration");
		return modelAndView;
	}
	
	@GetMapping("/Admin")
	public ModelAndView adminlogin() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("Index");
		return modelAndView;
	}
	
	
	@PostMapping("/registrationform")
	public ModelAndView register1(UserDetails user) {
		
		ModelAndView modelAndView = new ModelAndView();
		int affectedrows=uservice.addUser(user);
		
		if(affectedrows==1)
		{modelAndView.setViewName("login");}
		else
			{modelAndView.setViewName("Registration");
			modelAndView.addObject("registrationfailure","Registration Unsuccessful");
			}
														
		return modelAndView;
	}
	
	@GetMapping("/dashboard")
	public ModelAndView dash() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("dashboard");
		return modelAndView;
	}
	
	
	@GetMapping("/productlist")
	public ModelAndView productlist() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("productlist");
		return modelAndView;
	
}
	@GetMapping("/orderlist")
	public ModelAndView orderlist() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("orderlist");
		return modelAndView;
	
}
	
	@GetMapping("/viewproduct")
	public ModelAndView viewproduct() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("viewproduct");
		return modelAndView;
	
}
}
