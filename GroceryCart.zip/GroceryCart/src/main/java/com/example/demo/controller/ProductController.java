package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.ProductDetails;
import com.example.demo.services.ProductService;

@Controller
@ResponseBody
public class ProductController {
	@Autowired
	ProductService pservice;

	@GetMapping("/addProduct")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("addProduct");
		return modelAndView;
	}

	@PostMapping("/addProduct1")
	public ModelAndView addProduct(ProductDetails product) {
		ModelAndView modelAndView = new ModelAndView();
		System.out.println(product);
		int affectedRows = pservice.addProduct(product);
		if (affectedRows == 1) {
			modelAndView.setViewName("addProduct");
			modelAndView.addObject("result", "Product addition SUCCESSFULL");
		} else {
			modelAndView.setViewName("addProduct");
			modelAndView.addObject("result", "Not updated");
		}
		return modelAndView;
	}

	@PostMapping("/getProduct")
	public ArrayList<ProductDetails> getMessage(@RequestParam("prodId") int prodId) {
		return pservice.displayProduct(prodId);
	}

}
