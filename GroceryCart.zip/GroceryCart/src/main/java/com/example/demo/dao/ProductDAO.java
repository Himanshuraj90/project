package com.example.demo.dao;

import java.sql.*;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.demo.model.ProductDetails;

@Repository
public class ProductDAO {

	public static Connection connectToDB() {
		Connection connection = null;
		try {
			// STEP - 1 : Register the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");

			// STEP - 2 Connecting with oracle database
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return connection;
		}

		catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public int addProduct(ProductDetails product) {
		System.out.println(product);

		int affectedRows = 0;
		// STEP-3 Create Statement
		try {
			Connection con = connectToDB();
			PreparedStatement stmt = con.prepareStatement("insert into product_tbl values(?,?,?,?,?,?)");
			stmt.setInt(1, product.getProdId());
			stmt.setString(2, product.getProdName());
			stmt.setString(3, product.getCategory());
			stmt.setString(4, product.getDescription());
			stmt.setInt(5, product.getStock());
			stmt.setInt(6, product.getPrice());

			// step 4 - execute sql query

			affectedRows = stmt.executeUpdate();

			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return affectedRows;

	}

	public ArrayList<ProductDetails> displayProduct(int prodId2) {
		ArrayList<ProductDetails> productList = new ArrayList<ProductDetails>();
		try {
			Connection con = connectToDB();

			PreparedStatement stmt1 = con.prepareStatement("select * from product_tbl");

			ResultSet rs = stmt1.executeQuery();

			while (rs.next()) {
				ProductDetails x = new ProductDetails();
				int prodId = rs.getInt(1);
				String prodName = rs.getString(2);
				String category = rs.getString(3);
				String description = rs.getString(4);
				int stock = rs.getInt(5);
				int price = rs.getInt(6);

				x.setProdId(prodId);
				x.setProdName(prodName);
				x.setCategory(category);
				x.setDescription(description);
				x.setStock(stock);
				x.setPrice(price);

				productList.add(x);
			}
			con.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return productList;
	}

}
