package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.ProductDetails;
import com.example.demo.model.UserDetails;
import com.example.demo.services.ProductService;
import com.example.demo.services.UserService;



@Controller
@ResponseBody
 public class ProductController {
	@Autowired
	ProductService pservice;
	
	@PostMapping("/addProduct")
	public String addUser (@RequestBody ProductDetails product) {
	
		int affectedRows = pservice.addProduct(product);
		if(affectedRows==1)
		return "1 Product added";
		else
			return "No Product added";
	}
	

	@GetMapping("/getProduct")
	public ArrayList<ProductDetails> getMessage(@RequestParam("prodId") int prodId) {
		return pservice.displayProduct(prodId);
	}
}
	

	

