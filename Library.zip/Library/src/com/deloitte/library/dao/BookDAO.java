package com.deloitte.library.dao;

import java.sql.*;

import com.deloitte.library.model.Book;

public class BookDAO {
	public static Connection connectToDB() {
		Connection connection=null;
		try {
			//Step 1  Register to driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//Step 2 Create Connection
			connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");
			return connection;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} 
		}
	
	
	public static void addBook(Book book) {

	System.out.println(book);
	try {	//Step 3 create the Statement
		Connection con=connectToDB();
		PreparedStatement stmt=connectToDB().prepareStatement("insert into Book values (?,?,?,?)");
		stmt.setInt(1,book.getBookId());
		stmt.setString(2,book.getBookName());
		stmt.setString(3,book.getAuthor());
		stmt.setInt(4,book.getPrice());
				//Step 4 execute SQL query
		int affectedRows = stmt.executeUpdate();
		System.out.println("Affected Rows="+affectedRows);
		//CLose the connection
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();}
	}
	
	
	public static void displayBook() {

		try {	//Step 3 create the Statement
			Connection con=connectToDB();
			PreparedStatement stmt=connectToDB().prepareStatement("Select * from Book");
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" " +rs.getString(3)+" " +rs.getInt(4));
			
			//CLose the connection
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
}







}
