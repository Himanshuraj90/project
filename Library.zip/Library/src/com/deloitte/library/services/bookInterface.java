package com.deloitte.library.services;
import java.util.*;
import com.deloitte.library.model.Book;

public interface bookInterface {

	public void addBook(String bookName,String author,int price);
	public boolean searchBook(int bookId,ArrayList<Book> c2 );
	public void displayBook();
	
}
