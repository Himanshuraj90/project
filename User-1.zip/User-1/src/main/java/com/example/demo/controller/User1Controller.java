package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.modal.User1Details;
import com.example.demo.service.User1Service;

@Controller
@ResponseBody
public class User1Controller {
	@Autowired
	User1Service service;

	@RequestMapping("/")
	public ArrayList<User1Details> getMessage(@RequestParam("userId")  int userId,@RequestParam("email") String email,@RequestParam("userName") String userName,@RequestParam("phNo") String phNo,@RequestParam("name") String name,@RequestParam("pass") String pass) {
		User1Details user1=new User1Details();
		user1.setEmail(email);
		user1.setName(name);
		user1.setPass(pass);
		user1.setPhNo(phNo);
		user1.setUserId(userId);
		user1.setUserName(userName);
		service.adddata(user1);
		
		return (service.display());
	}

}
