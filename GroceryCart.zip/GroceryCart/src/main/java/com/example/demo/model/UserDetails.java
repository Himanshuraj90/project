package com.example.demo.model;

public class UserDetails {


		 
		private int userId;
		private String email;
		private String phNo;
		private String name;
		private String userName;
		private String password;

		public UserDetails() {
			super();
		}

		public int getUserId() {
			return userId;
		}

		public void setUserId(int userId) {
			this.userId = userId;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPhNo() {
			return phNo;
		}

		public void setPhNo(String phno2) {
			this.phNo = phno2;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getuserName() {
			return userName;
		}

		public void setuserName(String userName) {
			this.userName = userName;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		@Override
		public String toString() {
			return "UserDetails [userId=" + userId + ", email=" + email + ", phNo=" + phNo + ", name=" + name
					+ ", userName=" + userName + ", password=" + password + "]";
		}
		

	}




