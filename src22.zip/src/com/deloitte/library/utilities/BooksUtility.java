package com.deloitte.library.utilities;
import java.sql.SQLException;

import com.deloitte.library.exception.BookNameException;

public class BooksUtility {
	
	
	public static void nameValidation(String bname) throws BookNameException {
		String pattern ="^[A-Za-z]+$";
		if(!bname.matches(pattern)) {
			throw new BookNameException("Name can only have characters");
			
		
			
		}
	}
	

}
