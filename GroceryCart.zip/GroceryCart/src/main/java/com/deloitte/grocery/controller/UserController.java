package com.deloitte.grocery.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.deloitte.grocery.model.UserDetails;
import com.deloitte.grocery.services.UserService;



@Controller	
@ResponseBody
public class UserController {
	@Autowired
	UserService service;
	
	@PostMapping("/")
	public String addUser (@RequestBody UserDetails user) {
		System.out.println("controller");
		int affectedRows = service.addUser(user);
		if(affectedRows==1)
		return "1 Row added";
		else
			return "No row added";
	}

	

	
}
