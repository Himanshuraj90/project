package com.deloitte.grocery.services;

import java.util.ArrayList;

import com.deloitte.grocery.model.UserDetails;

public class Service implements ServiceInterface {

	public void addUser(int userId, String name, String email, String userName, String phNo, String pass) {
		
		UserDetails u2=new UserDetails();
		u2.setUserId(userId);
		u2.setEmail(email);
		u2.setName(name);
		u2.setPass(pass);
		u2.setUserName(userName);
		u2.setPhNo(phNo);
	    UserDAO.addUser(u2);
	}

	public ArrayList<UserDetails> displayUser() {
		
		return UserDAO.displayuser();
	}
	
	public boolean loginUser(String userName,String pass) {
		
		return (UserDAO.login(userName, pass));
		
	}

}
