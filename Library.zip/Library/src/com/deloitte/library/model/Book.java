package com.deloitte.library.model;


public class Book {

	private int bookId;
	private String bookName;
	private String author;
	private int price;
	private static int count=0;

	
	public Book() {
		count++;
		// TODO Auto-generated constructor stub
	}

	
	public static int getCount() {
		return count;
	}


	public static void setCount(int count) {
		Book.count = count;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", author=" + author + ", price=" + price + "]";
	}

}
