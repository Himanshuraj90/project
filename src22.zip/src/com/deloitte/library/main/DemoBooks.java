package com.deloitte.library.main;

import java.util.*;

import com.deloitte.library.exception.BookNameException;
import com.deloitte.library.model.Books;
import com.deloitte.library.services.BookInterfaceImplementation;
import com.deloitte.library.utilities.BooksUtility;





public class DemoBooks extends BookInterfaceImplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		 ArrayList<Books> books = new ArrayList<Books>();
		 BookInterfaceImplementation mainObj = new BookInterfaceImplementation();
			while (true) {
				System.out.println("Please select an option");
				System.out.println("option 1 to add books ");
				System.out.println("option 2 to display books");
				System.out.println("option 3 to search for a book");
				System.out.println("option 4 to delete a book record");
				System.out.println("option 5  to exit the application");
				
				String option = sc.next();
			

				switch (option) {
				case "1":
					String bname, author;
					int bprice;
                System.out.println("Enter book details");
            	System.out.println("Enter book id");
            	int bId = Integer.parseInt(sc.next());
				System.out.println("Enter book name");
				bname =sc.next();
					try {
						BooksUtility.nameValidation(bname);
					} catch (BookNameException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				System.out.println("Enter book price");
				bprice = Integer.parseInt(sc.next());
				System.out.println("Enter book author");
				author = sc.next();
				
               mainObj.insertBook(bId,bname, author, bprice);
				break;
				
				case "2" : 
					System.out.println("Displaying the database ");
					
				System.out.println(mainObj.display());
				
					break;
				
				case "3" :
					System.out.println("Enter the book name");
					String bname1 = sc.next();
					boolean anss = mainObj.searchBooks(bname1);
					if(anss)
						System.out.println("book found!");
					else
						System.out.println("Sorry! The book doesn't exist");
				break;
				
				case "4" :
					System.out.println("Enter the book id");
					int bid = Integer.parseInt(sc.next());
					int rep = mainObj.deleteBooks(bid);
					if(rep!=0) {
						System.out.println("Book id : " + bid + " deleted.");
					}
					else 
						System.out.println("book id not there in the system");
					break;
				
				
				case "5" :
					System.out.println("Application ended");
					System.exit(0);
					break;

	}

}
}
}