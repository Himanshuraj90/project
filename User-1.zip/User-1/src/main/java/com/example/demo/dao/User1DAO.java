package com.example.demo.dao;

import java.sql.*;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.demo.modal.User1Details;





@Repository
public class User1DAO {
	public static Connection connectToDB() {
		Connection connection = null;
		try {
			// Step 1 Register to driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// Step 2 Create Connection
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return connection;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	
	
	
	public  ArrayList<User1Details> displayuser() {
		ArrayList<User1Details> table = new ArrayList<User1Details>();
		try { // Step 3 create the Statement
			Connection con = connectToDB();
			PreparedStatement stmt = con.prepareStatement("Select * from user_tbl");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				User1Details x = new User1Details();
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String email = rs.getString(3);
				String phNo = rs.getString(4);
				String userName = rs.getString(5);
				String pass = rs.getString(6);
				x.setUserId(id);
				x.setName(name);
				x.setEmail(email);
				x.setPhNo(phNo);
				x.setUserName(userName);
				x.setPass(pass);
				table.add(x);

			}

			// CLose the connection
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return table;
	}

	
	
}
