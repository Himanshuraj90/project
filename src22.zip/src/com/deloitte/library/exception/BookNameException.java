package com.deloitte.library.exception;

public class BookNameException extends Exception {
	public String detailMessage;
	
	
	
	public BookNameException(String message) {
		// TODO Auto-generated constructor stub
	detailMessage = message;
	}



	public String getMessage() {
	return detailMessage;
	}

}
