package com.deloitte.library.main;
import java.util.*;

import com.deloitte.library.dao.BookDAO;
import com.deloitte.library.model.Book;
import com.deloitte.library.services.Work;

public class DemoClass {

	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		int y=0;
		ArrayList<Book> b1=new 	ArrayList<Book>();
		Work i2=new Work();
		while (true)
			
		{
			System.out.println("Enter your choice of work ------");
			System.out.println("1 for add new Book ");
			System.out.println(" 2 for searching  book ");
			System.out.println("3 to display all books" );
			System.out.println("4 to exit the application");
			y=sc.nextInt();
		
			switch (y) {
			
			case 1: {			
				    	
					
					System.out.println("Enter name of Book");
					String bookName = sc.next();
					System.out.println("Enter name of Author");
					String author = sc.next();
					System.out.println("Enter price of Book");
					int price = Integer.parseInt(sc.next());
					i2.addBook(bookName,author,price);
					break;
					
			}
			
			case 2: {
				
				System.out.println("Enter bookid to search details");
			    int ch=Integer.parseInt(sc.next());
				Boolean res = i2.searchBook(ch,b1);
				if(res==true)
					System.out.println("Book Found");
				else
					System.out.println("Book Not Found");
				break;
			}
				
				
			
				
			case 3: {
				BookDAO.displayBook();
			break;
		
				
				
				
			}

			case 4:	{System.exit(0);
			break;}
			}
			

		}
		
	}}

	
	

